#ifndef TEMPLATE_SOLUTION_H
#define TEMPLATE_SOLUTION_H

#include <string>
#include <vector>
#include <iostream>

class Solution {
public:
  //std::string PrintHelloWorld();
  double FindMedian(std::vector<unsigned int> &inputs); 

};

#endif