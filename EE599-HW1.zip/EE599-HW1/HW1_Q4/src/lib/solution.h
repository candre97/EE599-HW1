#ifndef TEMPLATE_SOLUTION_H
#define TEMPLATE_SOLUTION_H

#include <string>
#include <vector>
#include <iostream>

class Solution {
public:
  std::string PrintHelloWorld();
  std::string PrintName();
  std::string PrintDOB();
  std::string PrintHeight(); 
  std::string PrintWeight(); 
  // int ex1(int n); 
  // int ex2(int n);  
};

#endif